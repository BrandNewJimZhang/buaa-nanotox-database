export default function Header() {
  return (
    <header>
      <span>Nanotoxicology Database</span>
    </header>
  )
}